;;; -*- Mode: Text -*-

;; LISP

;; INTRODUZIONE

Questa libreria implementa diverse operazioni standard per la manipolazione di polinomi come ad esempio:
- estrazione dei coefficienti 
- calcolo del grado del polinomio
- valutazione in un punto
- somma 
- moltiplicazione


Rappresentazione di una VARPOWER
Le VARPOWER saranno rappresentante nel seguente modo

(V Exponent VariableSymbol)

ESEMPIO:
(V 1 X)


Rappresentazione di un MONOMIO (Monomial):
I MONOMI saranno rappresentati nel seguente modo

(M Coefficient, TotalDegree, VarsPowers)

ESEMPIO:
(M 1 0 NIL)
(M 1 1 ((V 1 S)))
(M 1 7 ((V 3 S) (V 3 T) (V 1 Y)))


Rappresentazione di un POLINOMIO (Polynomial):
I POLINOMI saranno rappresentati nel seguente modo

(POLY (Monomials) [Un poly � una lista di monomi]

ESEMPIO:
(POLY ((M 1 1 ((V 1 X))) (M 1 2 ((V 2 X))) (M 1 3 ((V 3 X)))))


;; FUNZIONI IMPLEMENTATE 

Funzione VARPOWER-SYMBOL/1:

varpower-symbol (VP -> Integer)
Data in input una struttura di tipo VP, ritorna la variabile di VP.

CL-USER> (varpower-symbol '(V 3 S))
S



Funzione VARPOWER-POWER/1:

varpower-power (VP -> Integer)
Data in input una struttura di tipo VP, ritorna l'esponente della VP.

CL-USER> (varpower-power '(V 3 S))
3



Funzione VARPOWERS/1:

varpowers (Monomial -> VP-list)
Data in input una struttura di tipo Monomial, ritorna la lista di varpowers VP-list.
Se l'input non � parsato verr� parsato (se possbile).

CL-USER> (varpowers '(M 1 7 ((V 3 S) (V 3 T) (V 1 Y))))
((V 3 S) (V 3 T) (V 1 Y))

CL-USER> (varpowers '(* b a c))
((V 1 A) (V 1 B) (V 1 C))



Funzione VARS-OF:

vars-of (Monomial -> Variables)
Data in input una struttura di tipo Monomial, ritorna la lista di variabili Variables.
Se l'input non � parsato verr� parsato (se possbile).

CL-USER> (vars-of '(M 1 7 ((V 3 S) (V 3 T) (V 1 Y))))		
(S T Y)

CL-USER> (vars-of '(* 42 x a))
(A X)



Funzione MONOMIAL-DEGREE/1:

monomial-degree (Monomial -> TotalDegree)
Data in input una struttura di tipo Monomial, ritorna il suo grado totale TotalDegree.
Se l'input non � parsato verr� parsato (se possbile).

CL-USER> (monomial-degree '(* 42 (expt a 2) x (expt ciao 3)))
6

CL-USER> (monomial-degree '(M 1 7 ((V 3 S) (V 3 T) (V 1 Y))))		
7



Funzione MONOMIAL-COEFFICIENT/1:

monomial-coefficient (Monomial -> Coefficient)
Data in input una struttura di tipo Monomial, ritorna il suo coefficiente Coefficient.
Se l'input non � parsato verr� parsato (se possbile).

CL-USER> (monomial-coefficient '(* a t (expt t 4)))
1

CL-USER> (monomial-coefficient '(M 5 7 ((V 3 S) (V 3 T) (V 1 Y))))
5



Funzione IS-MONOMIAL/1:

is-monomial (Espressione -> Boolean)
Data in input un'espressione, ritorna TRUE se l'espressione in input � un monomio.

CL-USER> (is-monomial '(M 5 7 ((V 3 S) (V 3 T) (V 1 Y))))
T

CL-USER> (is-monomial 'prova)
NIL



Funzione IS-VARPOWER/1:

is-varpower (Espressione -> Boolean)
Data in input un'espressione, ritorna TRUE se l'espressione in input � una VP.

CL-USER> (is-varpower'(V 3 S))
T

CL-USER> (is-varpower 'prova)
NIL



Funzione REMOVE-COEFF-ZERO/1:

remove-coeff-zero (Monomials -> Monomials)
Data in input una lista di Monomi, ritorna i Monomi eliminando quelli con coefficiente 0.

CL-USER> (remove-coeff-zero '((M 0 1 ((V 1 X))) (M 1 2 ((V 2 X))) (M 1 3 ((V 3 X)))))
((M 1 2 ((V 2 X))) (M 1 3 ((V 3 X))))

CL-USER> (remove-coeff-zero '((M 1 1 ((V 1 X))) (M 0 2 ((V 2 X))) (M 1 3 ((V 3 X)))))
((M 1 1 ((V 1 X))) (M 1 3 ((V 3 X))))



Funzione MONOMIALS/1:

monomials (Polynomial -> Monomials)
Data in input una struttura di tipo Polynomial, ritorna i Monomi che compongono il Polynomial in input.

CL-USER> (monomials '(POLY ((M -4 0 NIL))))
((M -4 0 NIL))

CL-USER> (monomials '(POLY ((M -4 0 NIL) (M 1 1 ((V 1 X))) (M 0 2 ((V 2 X))))))
((M -4 0 NIL) (M 1 1 ((V 1 X))) (M 0 2 ((V 2 X))))



Funzione IS-POLYNOMIAL/1:

is-polynomial (Polynomial -> Boolean)
Data in input una struttura di tipo Polynomial, ritorna i Monomi che compongono il Polynomial in input.

CL-USER> (is-polynomial '(POLY ((M -4 0 NIL) (M 1 1 ((V 1 X))) (M 0 2 ((V 2 X))))))
T

CL-USER> (is-polynomial '(((M -4 0 NIL) (M 1 1 ((V 1 X))) (M 0 2 ((V 2 X))))))
NIL

CL-USER> (is-polynomial 'prova)
NIL



Funzione COEFFICIENTS/1:

coefficients (Polynomial -> Coefficients)
Data in input una struttura di tipo Polynomial, ritorna i Coefficients dei Monomi che compongono il Polynomial in input.
Se l'input non � parsato verr� parsato (se possbile).

CL-USER> (coefficients '(+ (* a) (* (expt x 0))))
(1 1)

CL-USER> (coefficients '(POLY ((M -4 0 NIL) (M 1 1 ((V 1 X))) (M 0 2 ((V 2 X))))))
(-4 1 0)



Funzione VARIABLES/1:

variables (Polynomial -> Variables)
Data in input una struttura di tipo Polynomial, ritorna i Variables dei Monomi che compongono il Polynomial in input.
Se l'input non � parsato verr� parsato (se possbile).

CL-USER> (variables '(+ (* 0 x) (* 42 (expt a 4))))
(A)

CL-USER> (variables '(POLY ((M -4 0 NIL) (M 1 1 ((V 1 Y))) (M 1 2 ((V 2 X))))))
(Y X)



Funzione MAXDEGREEE/1:

maxdegree (Polynomial -> Degree)
Data in input una struttura di tipo Polynomial, ritorna il TD pi� alto
tra i Monomi che compongono il Polynomial in input.
Se l'input non � parsato verr� parsato (se possbile).

CL-USER> (maxdegree '(POLY ((M -4 0 NIL) (M 1 1 ((V 1 Y))) (M 1 2 ((V 2 X))))))
2

CL-USER> (maxdegree '(POLY ((M -4 0 NIL) (M 1 1 ((V 1 Y))))))
1



Funzione MINDEGREEE/1:

mindegree (Polynomial -> Degree)
Data in input una struttura di tipo Polynomial, ritorna il TD pi� basso
tra i Monomi che compongono il Polynomial in input.
Se l'input non � parsato verr� parsato (se possbile).

CL-USER> (mindegree '(POLY ((M 1 1 ((V 1 Y))) (M 1 2 ((V 2 X))))))
1

CL-USER> (mindegree '(POLY ((M 1 2 ((V 2 X))) (M 1 3 ((V 3 X))))))
2



Funzione EVAL-AS-NUMBER/1:

eval-as-number (Expression -> Number)
Data in input un'espressione, se � un numero ritorna il numero stesso,
se � una funzione composta calcola il risultato.

CL-USER> (eval-as-number '(cos 30))
0.15425146

CL-USER> (eval-as-number 30)
30

CL-USER> (eval-as-number (+ 20 30))
50

CL-USER> (eval-as-number '(prova))
NIL



Funzione IS-POWER-NOT-PARSED/1:

is-power-not-parsed (Expression -> Boolean)
Data in input un'espressione, se tale espressione � una lista del tipo (expt varsymbol number)
allora ritorna TRUE.

CL-USER> (is-power-not-parsed '(expt s 3))
T

CL-USER> (is-power-not-parsed '(V 1 X))
NIL



Funzione PARSE-POWER/1:

parse-power (Expression -> Monomial)
Data in input un'espressione, se tale espressione � una lista del tipo (expt varsymbol number)
allora tale espressione verr� parsata in formato (MONO 1 TD (VP)).

CL-USER> (parse-power '(expt s 3))
(M 1 3 (V 3 S))



Funzione PARSE-POWER-NEGATIVE-COEFF/1:

parse-power-negative-coeff (Expression -> Monomial)
Data in input un'espressione, se tale espressione � una lista del tipo (expt varsymbol number)
allora tale espressione viene parsata in formato (MONO -1 TD (VP)).

CL-USER> (parse-power-negative-coeff '(expt s 3))
(M -1 3 (V 3 S))



Funzione IS-OPERATOR/1:

is-operator (Expression -> Boolean)
Data in input un'espressione, se tale espressione � un operatore algebrico (*, / , + , -)
ritorna TRUE.

CL-USER> (is-operator '*)
T

CL-USER> (is-operator '+)
T

CL-USER> (is-operator 'a)
NIL



Funzione SORT-MONOMIAL/1:

sort-monomial (Monomial -> Monomial)
Data in inputuna struttura del tipo Monomial, restituisce tale Monomio ordinato secondo ordine lessicografico

CL-USER 15 > (sort-monomial '(M 1 3 ((V 1 B)(V 1 A)(V 1 C))))
(M 1 3 ((V 1 A) (V 1 B) (V 1 C)))



Funzione COMPARE-VARPOWERS/2:

compare-varpowers (VP1, VP2 -> Boolean)
Date in input due strutture di tipo VP, restituisce TRUE se la variabile di VP1 , in ordine alfabetico,
viene prima rispetto a quella di VP2.


CL-USER> (compare-varpowers '((V 1 A)) '((V 1 B)))
T

CL-USER> (compare-varpowers '((V 1 B)) '((V 1 A)))
NIL



Funzione COMPARE-DEGREES/2:

compare-degrees (Monomial1, Monomial2 -> Boolean)
Date in input due strutture di tipo Monomial, restituisce TRUE se il TD di Monomial1 � minore
del TD di Monomial2

CL-USER> (compare-degrees '(M 1 6 ((V 2 A)(V 3 A)(V 1 C))) '(M 1 2 ((V 2 A))))
NIL

CL-USER> (compare-degrees '(M 1 2 ((V 2 A))) '(M 1 6 ((V 2 A)(V 3 A)(V 1 C))))
T



Funzione SORT-POLY/1:

sort-poly (Monomials -> Monomials)
Date in input una strutture di tipo Monomials, ovvero i monomi che compongono un Polynomial, restituisce
la lista di Monomials ordinati lessicograficamente.

CL-USER> (sort-poly '((M 1 2 ((V 2 C))) (M 1 1 ((V 1 A))) (M 1 3 ((V 3 Z)))))
((M 1 1 ((V 1 A))) (M 1 2 ((V 2 C))) (M 1 3 ((V 3 Z))))


CL-USER> (sort-poly '((M 1 2 ((V 2 C))) (M 1 1 ((V 1 A))) (M 1 3 ((V 3 Z))) (M 1 2 ((V 2 A)))))
((M 1 1 ((V 1 A))) (M 1 2 ((V 2 A))) (M 1 2 ((V 2 C))) (M 1 3 ((V 3 Z))))



Funzione BUILD-COEFFFICIENT/1:

build-coefficient (Expression -> Number)
Date in input una generica Expression ritorna il Coefficient risultante dal parsing di tale Expression.

CL-USER> (build-coefficient '(* 2 6 Y X K))
12



Funzione BUILD-VARPOWERS/1:

build-varpowers (Expression -> (TD (VPS))
Date in input una generica Expression ritorna la struttura (TD (VPS)) risultante dal parsing di tale Expression.

CL-USER> (build-varpowers '(2 6 Y X K) 0)
(3 (V 1 K) (V 1 X) (V 1 Y))



Funzione AS-MONOMIAL/1:

as-monomial (Expression -> Monomial)
Date in input un'espressione , (se possbile) verr� parsata nella struttura Monomial
ordinata e ridotta.

CL-USER 7 > (as-monomial '(* 10 (expt a 0) c (expt b 2) (expt a 2) (expt b 2)))
(M 10 7 ((V 2 A) (V 4 B) (V 1 C)))



Funzione AS-MONOMIAL-UNORDERED/1:

as-monomial-unordered (Expression -> Monomial)
Date in input un'espressione , (se possbile) verr� parsata nella struttura Monomial
senza per� tener conto di riduzioni possibili e ordinamento.

CL-USER 4 > (as-monomial-unordered '(* 10 (expt a 0) c (expt b 2)))
(M 10 3 ((V 2 B) (V 1 C)))

CL-USER> (as-monomial-unordered '(* 10 (expt a 0) c (expt b 2) (expt a 2) (expt b 2)))
(M 10 5 ((V 2 B) (V 2 B) (V 1 C)))

CL-USER> (as-monomial-unordered '(* 10 (expt a 0) c (expt b 2) (expt a 2) (expt b 2)))
(M 10 7 ((V 2 B) (V 2 A) (V 2 B) (V 1 C)))



Funzione AS-POLYNOMIAL/1:

as-polynomial (Expression -> Polynomial)
Date in input un'espressione , (se possbile) verr� parsata nella struttura Polynomial
ordinata e ridotta.

CL-USER> (as-polynomial '(+ (* 2 b) (* b) (* 3 c) (* 4 a)))
(POLY ((M 4 1 ((V 1 A))) (M 3 1 ((V 1 B))) (M 3 1 ((V 1 C)))))



Funzione AS-POLYNOMIAL-CALL/1:

as-polynomial-call (Expression -> Polynomial)
Date in input un'espressione , (se possbile) verr� parsata nella struttura Polynomial
senza per� tener conto di riduzioni possibili e ordinamento.

CL-USER> (as-polynomial-call '(+ (* 2 b) (* b) (* 3 c) (* 4 a)))
((M 2 1 ((V 1 B))) (M 1 1 ((V 1 B))) (M 3 1 ((V 1 C))) (M 4 1 ((V 1 A))))



Funzione CHECK-EQUAL-VARIABLES/1:

check-equal-variables (Monomials -> Boolean)
Dati in input due Monomi , ritorna TRUE se i due monomi hanno le stesse variabili.

CL-USER> (check-equal-variables '((M 2 1 ((V 1 B))) (M 1 1 ((V 1 B)))))
T

CL-USER> (check-equal-variables '((M 2 1 ((V 1 B))) (M 1 1 ((V 1 A)))))
NIL



Funzione SUM-SIMILAR-MONOS-IN-POLY/1:

sum-similar-monos-in-poly (Monomials -> Monomials)
Data in input la lista di Monomial che compongono un Poy , 
ritorna la lista dei Monomial ridotti.

CL-USER> (sum-similar-monos-in-poly '((M 2 1 ((V 1 B))) (M 1 1 ((V 1 B)))))
((M 3 1 ((V 1 B))))

CL-USER> (sum-similar-monos-in-poly '((M 2 1 ((V 1 B))) (M 1 1 ((V 1 B))) (M 1 1 ((V 1 B)))))
((M 4 1 ((V 1 B))))



Funzione COMPRESS-VARS-IN-MONOMIAL/1:

compress-vars-in-monomial (Monomial -> Monomial)
Data in input una struttura di tipo Monomial (gi� ordinata), ritorna il Monomial ridotto.

CL-USER> (compress-vars-in-monomial '(M 2 6 ((V 1 A) (V 2 A) (V 1 B) (V 1 B) (V 2 B))))
(M 2 6 ((V 3 A) (V 4 B)))

CL-USER> (compress-vars-in-monomial '(M 2 1 ((V 1 B) (V 1 B) (V 2 B) (V 2 B))))
(M 2 1 ((V 6 B)))



Funzione COMPRESS-VPS/1:

compress-vps (VPS -> VPS)
Data in input una struttura di tipo VPS , ovvero una lista di VP
(gi� ordinata), ritorna la VPS ridotta.

CL-USER> (compress-vps '((V 1 B) (V 1 B) (V 2 B) (V 2 B)))
((V 6 B))

CL-USER> (compress-vps '((V 1 A) (V 2 A) (V 1 B) (V 1 B) (V 2 B)))
((V 3 A) (V 4 B))



Funzione NEW-PAIRLIS/2:

new-pairlis (List1, List2 -> List)
Date in input due liste List1 e List2 , ritorna una lista alternata di elementi
di List1 e List2.

CL-USER> (new-pairlis '(a b c) '(1 2 3))
((A 1) (B 2) (C 3))



Funzione CHANGE-SIGN/1:

change-sign (Monomials -> Monomials)
Data in input la lista di Monomial che compongono un Polynomial , 
ritorna la lista dei Monomi con il Coefficiente invertito di segno.

CL-USER> (change-sign '((M 2 1 ((V 6 B)))))
((M -2 1 ((V 6 B))))

CL-USER> (change-sign '((M -2 1 ((V 6 B))) (M 1 1 ((V 1 X)))))
((M 2 1 ((V 6 B))) (M -1 1 ((V 1 X))))



Funzione TO-POLYNOMIAL/1:

to-polynomial (Expression -> Polynomial )
Data in input un'espressione, se � gi� un Polynomial lo ritorna inalterato,
se � un Monomial costruir� la struttura Polynomial(Monomial)

CL-USER> (to-polynomial '(+ (* 0 (expt x 3)) (* (expt y 0)) (* a) (* (expt a 2))))
(POLY ((M 1 0 NIL) (M 1 1 ((V 1 A))) (M 1 2 ((V 2 A)))))

CL-USER> (to-polynomial '((M -2 1 ((V 6 B))) (M 1 1 ((V 1 X)))))
(POLY ((M 2 1 ((V 1 M)))))



Funzione POLYVAL/2:

polyval (Expression, Values -> Number )
Data in input un'espressione Expression e una lista di valori Values, 
se l'espressione � gi� un Polynomial non lo parsa, se non lo � ed � possibile
parsarla, allora parsa l'Expression nella struttura Polynomial e valuta il Polynomial ottenuto 
nel punto dello spazio definto da Values.


CL-USER 2 > (setf pol2 (as-polynomial '(+ (* a) (* b) (* (expt c 2)))))
(POLY ((M 1 1 ((V 1 A))) (M 1 1 ((V 1 B))) (M 1 2 ((V 2 C)))))

CL-USER 3 > (polyval pol2 '(1 2 3))
12

CL-USER> (polyval '(+ (* a) (* b) (* (expt c 2))) '(1 2 3))
12



Funzione SUBSTITUTE-VAR-IN-VP/2:

substitute-var-in-vp (VP, Alternate -> VP)
Data in input una struttura di tipo VP e una lista Alternate contenente
liste di coppie (VARIABILE VALORE), sostituisce la VARIABILE di VP
con il VALORE presente nella coppia Alternate ogni qualvolta la VARIABILE 
di Alternate � uguale alla VARIABILE di VP

CL-USER> (substitute-var-in-vp '(V 1 X) '((X 1)))
(V 1 1)



Funzione SUBSTITUTE-VARS-IN-VPS/2:

substitute-vars-in-vps (VPS, Alternate -> VPS)
Data in input una struttura di tipo VPS , ovvero una lista di VP ,
e una lista Alternate contenente liste di coppie (VARIABILE VALORE), scorre tutte le VP
della VPS e sostituisce la VARIABILE di VP con il VALORE presente nella coppia Alternate
ogni qualvolta la VARIABILE di Alternate � uguale alla VARIABILE di VP.

CL-USER> (substitute-vars-in-vps '((V 1 X) (V 1 Y)) '((X 1) (Y 1)))
((V 1 1) (V 1 1))



Funzione SUBSTITUTE-VARS-IN-MONO/2:

substitute-vars-in-mono (Monomial, Alternate -> VPS)
Data in input una struttura di tipo Monomial e una lista Alternate contenente liste 
di coppie (VARIABILE VALORE), scorre tutte le VP contenute nella VPS del Monomial
e sostituisce la VARIABILE di VP con il VALORE presente nella coppia Alternate,
ogni qualvolta la VARIABILE di Alternate � uguale alla VARIABILE di VP.

CL-USER> (substitute-vars-in-mono '((M 1 1 ((V 1 B))) (M 2 2 ((V 1 C))) (M -1 2 ((V 2 A)))) '((A 1) (B 2) (C 3)))
((M 1 1 ((V 1 2))) (M 2 2 ((V 1 3))) (M -1 2 ((V 2 1))))



Funzione EVALUATE-MONOS/1:

evaluate-monos (Monomials -> Number)
Data in input una struttura di tipo Monomials, ovvero la lista di Monomial che compongono
un Polynomial, con valori delle variabili gi� sostituiti mediante l'utilizzo di SUBSTITUTE-VARS-IN-MONO, 
ritorna il valore della valutazione dei Monomials.

CL-USER> (evaluate-monos '((M 1 1 ((V 1 2))) (M 2 2 ((V 1 3))) (M -1 2 ((V 2 1)))))
7


Funzione EVALUATE-VPS/1:

evaluate-vps (VPS -> Number)
Data in input una struttura di tipo VPS, ovvero la lista di VP che compongono
un Monomial, con valori delle variabili gi� sostituiti mediante l'utilizzo di SUBSTITUTE-VARS-IN-VP, 
ritorna il valore della valutazione delle VP di VPS.

CL-USER> (evaluate-vps '((V 1 2) (V 1 3) (V 2 1)))
6



Funzione POLYPLUS/2:

polyplus (Polynomial1, Polynomial2 -> Polynomial)
Dati in input Polynomial1 e Polynomial2 , due strutture di tipo Polynomial, ritorna
il Polynomial (ridotto e ordinato) risultante dalla somma di Polynomial1 e Polynomial2. Se Polynomial1 e Polynomial2 NON sono parsati
secondo la struttura Polynomial , (se possibile) verranno parsati prima di eseguire la somma.

CL-USER> (polyplus '(+ (* a) (* 2 (expt b 2))) '(+ (* 3 a) (* 2 (expt b 2))))
(POLY ((M 4 1 ((V 1 A))) (M 4 2 ((V 2 B)))))

CL-USER> (polyplus '(POLY ((M 2 2 ((V 2 B))))) '(POLY ((M 2 2 ((V 2 B))))))
(POLY ((M 4 2 ((V 2 B)))))



Funzione POLYMINUS/2:

polyminus (Polynomial1, Polynomial2 -> Polynomial)
Dati in input Polynomial1 e Polynomial2 , due strutture di tipo Polynomial, ritorna
il Polynomial (ridotto e ordinato) risultante dalla differenza di Polynomial1 e Polynomial2. Se Polynomial1 e Polynomial2 NON sono parsati
secondo la struttura Polynomial , (se possibile) verranno parsati prima di eseguire la differenza.

CL-USER> (polyminus '(POLY ((M 4 2 ((V 2 B))))) '(POLY ((M 2 2 ((V 2 B))))))
(POLY ((M 2 2 ((V 2 B)))))

CL-USER> (polyminus '(+ (* a) (* 4 (expt b 2))) '(+ (* a) (* 2 (expt b 2))))
(POLY ((M 2 2 ((V 2 B)))))

CL-USER> (polyminus '(+ (* 3 a) (* 4 (expt b 2))) '(+ (* a) (* 2 (expt b 2))))
(POLY ((M 2 1 ((V 1 A))) (M 2 2 ((V 2 B)))))



Funzione POLYTIMES/2:

polytimes (Polynomial1, Polynomial2 -> Polynomial)
Dati in input Polynomial1 e Polynomial2 , due strutture di tipo Polynomial, ritorna
il Polynomial (ridotto e ordinato) risultante dal prodotto di Polynomial1 e Polynomial2. Se Polynomial1 e Polynomial2 NON sono parsati
secondo la struttura Polynomial , (se possibile) verranno parsati prima di eseguire il prodotto.


CL-USER> (polytimes '(+ (* a) (* 4 (expt b 2))) '(+ (* a) (* 2 (expt b 2))))
(POLY ((M 1 2 ((V 2 A))) (M 6 3 ((V 1 A) (V 2 B))) (M 8 4 ((V 4 B)))))

CL-USER 21 > (setf poly1 (as-polynomial '(+ (* a) (* 4 (expt b 2)))))
(POLY ((M 1 1 ((V 1 A))) (M 4 2 ((V 2 B)))))

CL-USER 22 > (setf poly2 (as-polynomial '(+ (* a) (* 2 (expt b 2)))))
(POLY ((M 1 1 ((V 1 A))) (M 2 2 ((V 2 B)))))

CL-USER 23 > (polytimes poly1 poly2)
(POLY ((M 1 2 ((V 2 A))) (M 6 3 ((V 1 A) (V 2 B))) (M 8 4 ((V 4 B)))))


Funzione POLYTIMES-CALL/2:

polytimes-call (Monomials1, Monomials2 -> Monomials)
Dati in input Monomials1 e Monomials2 , ovvero le liste di Monomial che compongono rispettivamente i due polinomi Polynomial1 e Polynomial2
da moltiplicare, ritorna la lista di Monomial (non ridotta e non ordinata) risultante dal prodotto di Monomials1 e 
Monomials2.

CL-USER> (setf monos1 (monomials poly1))
((M 1 1 ((V 1 A))) (M 4 2 ((V 2 B))))

CL-USER> (setf monos2 (monomials poly2))
((M 1 1 ((V 1 A))) (M 2 2 ((V 2 B))))

CL-USER> (polytimes-call monos1 monos2)
((M 1 2 ((V 2 A))) (M 2 3 ((V 1 A) (V 2 B))) (M 4 3 ((V 1 A) (V 2 B))) (M 8 4 ((V 4 B))))



Funzione MONO-TIMES/2:

mono-times (Monomial1, Monomial2 -> Monomial)
Dati in input Monomial1 e Monomial2 , due strutture di tipo Monomial, ritorna il Monomial risultante dalla
moltiplicazione di Monomial1 e Monomial2.

CL-USER> (mono-times '(M 1 1 ((V 1 A))) '(M 1 1 ((V 1 A))))
(M 1 2 ((V 2 A)))



Funzione MULTIPLY-VARIABLES/2:

mono-times (VPS1, VPS2 -> VPS)
Dati in input VPS1 e VPS2 (ordinate), due strutture di tipo lista di VP, ritorna la VPS risultante dalla
moltiplicazione di VPS1 e VPS2.

CL-USER> (multiply-variables '((V 1 A)) '((V 1 A)))
((V 2 A))

CL-USER> (multiply-variables '((V 1 A) (V 1 B)) '((V 1 A) (V 1 B)))
((V 2 A) (V 2 B))



Funzione PPRINT-POLYNOMIAL/1:

pprint-polynomial (Polynomial -> NIL)
Dato in input una struttura di tipo Polynomial, stampa sullo STDOUTPUT
il Poynomial dato in input. (se il Polynomial in inpu  non � parsato,  ed � possibile parsarlo, verr� prima parsato
e successivamente stampato).

CL-USER> (pprint-polynomial '(POLY ((M 1 1 ((V 1 A))) (M 1 2 ((V 2 X))))))
(1 * A + 1 * X ^ 2)
NIL



Funzione PPRINT-POLYNOMIAL-CALL/1:

pprint-polynomial-call (Monomials -> NIL)
Dato in input una struttura Monomials, ovvero la lista di Monomial che compongono un Polynomials,  stampa sullo STDOUTPUT
Monomials.

CL-USER> (pprint-polynomial-call '((M 1 1 ((V 1 A))) (M 1 2 ((V 2 X)))))
(1 * A + 1 * X ^ 2)



Funzione PPRINT-POLYNOMIAL-CALL-COEFFICIENTS/1:

pprint-polynomial-call-coefficients (Monomial -> NIL)
Dato in input una struttura Monomial  stampa sullo STDOUTPUT i coefficienti e le  variabili del Monomial dato in input.

CL-USER> (pprint-polynomial-call-coefficients '(M 1 1 ((V 1 A))))
(1 * A)

CL-USER> (pprint-polynomial-call-coefficients '(M 1 2 ((V 1 A) (V 1 X))))
(1 * A * X)



Funzione PPRINT-POLYNOMIAL-CALL-VARIABLES/1:

pprint-polynomial-call-variables (VPS -> NIL)
Dato in input una struttural VPS stampa sullo STDOUTPUT le variabili del Monomial dato in input.


CL-USER> (pprint-polynomial-call-variables '((V 1 A) (V 1 X)))
(A * X)

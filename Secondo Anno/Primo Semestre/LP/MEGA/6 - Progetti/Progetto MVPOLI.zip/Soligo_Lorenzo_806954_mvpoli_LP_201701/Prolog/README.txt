%%% -*- Mode: Text -*-


%% INTRODUZIONE

Questa libreria implementa diverse operazioni standard per la
manipolazione di polinomi come ad esempio:
- estrazione dei coefficienti 
- calcolo del grado del polinomio
- valutazione in un punto
- somma 
- moltiplicazione

Rappresentazione di un MONOMIO (RAPPRESENTAZIONE STANDARD):
I MONOMI saranno rappresentati nel seguente modo

m(Coefficient, TotalDegree, VarsPowers).

ESEMPIO
m(1, 0, [])
m(3, 1, [v(1, w)])
m(1, 7, [v(3, s), v(3, t), v(1, y)])


Rappresentazione di una VARIABILE (RAPPRESENTAZIONE STANDARD):
Le VARIABILI saranno rappresentate nel seguente modo
v(Exp, Symbol)

ESEMPIO
v(1, x)


Rappresentazione di un POLINOMIO (RAPPRESENTAZIONE STANDARD):
I POLiNOMI saranno rappresentati nel seguente modo

poly(Monomials) [Un poly e' una lista di monomi]

ESEMPIO
P = poly([m(-4, 0, []), m(1, 2, [v(1, x), v(1, y)]), m(1, 7, [v(3, s), v(3, t), v(1, y)])])


%% PREDICATI IMPLEMENTATI

PREDICATO coefficients/2

coefficients(Monomio -> Integer)
Il predicato coefficients e' vero quando Coefficients e' una lista dei
coefficienti di Poly.

coefficients(m(-1, 1, [v(1, x)]), C1).
C1 = [-1].
coefficients(0 * x -3, C2).
C2 = [-3].



PREDICATO variables/2

variables(Polinomio -> Lista di Variabili)
Il predicato variables e' vero quando Variables e' una lista
dei simboli di variabile che appaiono in Poly.

variables(x * y * z, V1).
V1 = [x, y, z].
variables(poly([m(-3, 0, []), m(-4, 1, [v(1, x)])]), V2).
V2 = [x].



PREDICATO monomials/2

monomials(Polinomio -> Lista dei Monomi)
Il predicato monomials e' vero quando Monomials e' la
lista dei monomi che appaiono in Poly.

monomials(x + x + x + x, M1).
M1 = [m(4, 1, [v(1, x)])].
monomials(-pippo^123 * pluto, M2).
M2 = [m(-1, 124, [v(123, pippo), v(1, pluto)])].



PREDICATO maxdegree/2

maxdegree(Polinomio, Grado Massimo)
Il predicato maxdegree e' vero quando Degree e' il massimo
grado dei monomi che appaiono in Poly.

maxdegree(-a -b ^ 7 -c^2, MAX1).
MAX1 = 7.
maxdegree(a ^ 3 -b + ciao^2, MAX2).
MAX2 = 3.



PREDICATO mindegree/2

mindegree(Polinomio, Grado Minimo)
Il predicato mindegree e' vero quando Degree e' il minimo
grado dei monomi che appaiono in Poly.

mindegree(-a -b ^ 7 -c^2, MIN1).
MIN1 = 1.
mindegree(-b ^ 0 -b ^ 7 -b^2, MIN2).
MIN2 = 0.



PREDICATO polyplus/3

polyplus(Poly1, Poly2, Risultato)
Il predicato polyplus e' vero quando Result e' il polinomio somma di
Poly1 e Poly2 ordinato, polyplus richiama il predicato polyplus_call/3
la quale effettua la somma vera e propria.

polyplus(a^ 3, 3 * b, PP1).
PP1 = poly([m(3, 1, [v(1, b)]), m(1, 3, [v(3, a)])]).
polyplus(poly([m(1, 2, [v(1, a), v(1, b)])]), m(1, 2, [v(1, a), v(1, b)]), PP2).
PP2 = poly([m(2, 2, [v(1, a), v(1, b)])]).



PREDICATO polyminus/3

polyminus(Poly1, Poly2, Risultato)
Il predicato polyminus e' vero quando Result e' il polinomio
differenza di Poly1 e Poly2 ordinato, polyminus richiama il predicato
polyminus_call/3 la quale effettua la differenza vera e propria.

polyminus(a^ 3, 3 * b, PM1).
PM1 = poly([m(-3, 1, [v(1, b)]), m(1, 3, [v(3, a)])]).
polyminus(m(-1, 1, [v(1, x)]), 3 * x, PM2).
PM2 = poly([m(-4, 1, [v(1, x)])]).



PREDICATO polytimes/3

polytimes(Poly1, Poly2, Result)
Il predicato polytimes e' vero quando Result e' il polinomio
risultante, dalla moltiplicazione di Poly1 e Poly2, ordinato, effettua anche la
compatazione  delle variabili e la somma dei monomi simili. Il
predicato polytimes richiama il predicato polytimes_call il quale
effettua il prodotto vero e proprio senza effettuare riduzioni.

polytimes(1, a * b * c, PT1).
PT1 = poly([m(1, 3, [v(1, a), v(1, b), v(1, c)])]).
polytimes(x + y, a + b, PT2).
PT2 = poly([m(1, 2, [v(1, a), v(1, x)]), m(1, 2, [v(1, a), v(1, y)]), m(1, 2, [v(1, b), v(1, x)]), m(1, 2, [v(1, b), v(1, y)])]).



PREDICATO as_monomial/2

as_monomial(Expression, Monomial)
Il predicato as monomial e' vero quando Monomial e' il termine che
rappresenta il monomio risultante dal parsing" dell'espressione Expression.
Data la generale confusione sul fatto che questo predicato debba accettare
come primo parametro una forma del tipo (x + x + x), nel nostro caso 

as_monomial(pippo * pippo * pippo * pippo * pippo^5, AM1).
AM1 = m(1, 9, [v(9, pippo)]).
as_monomial(0 * a * b * c * quellochevoglio, AM2).
AM2 = m(0, 0, []).



PREDICATO as_polynomial/2

as_polynomial(Expression, Polynomial)
Il predicato as polynomial e' vero quando Polynomial e' il termine che
rappresenta il polinomio risultante dal parsing dell'espressione Expression.

as_polynomial(pippo + gennaro + 3 * pippo, AP1).
AP1 = poly([m(1, 1, [v(1, gennaro)]), m(4, 1, [v(1, pippo)])]).
as_polynomial(-3 * a ^ 4 +12 * a ^2 * a ^2, AP2).
AP2 = poly([m(9, 4, [v(4, a)])]).



PREDICATO polyval/3

polyval(Polynomial, VariableValues, Value)
Il predicato polyval e' vero quanto Value contiene il valore del
polinomio Polynomial (che puo' anche essere un monomio), nel punto
n-dimensionale rappresentato dalla lista VariableValues, che contiene
un valore per ogni variabile ottenuta con il predicato variables.

polyval(x * pippo, [0, 100000], PV1).
PV1 = 0.
polyval(poly([m(3, 1, [v(1, x)]), m(1, 2, [v(2, a)])]), [-1, -2], PV2).
PV2 = -5.



PREDICATO pprint polynomial/1

pprint_polynomial(Polynomial)
Il predicato pprint polynomial risulta vedo dopo aver stampato
(sullo standard output) una rappresentazione tradizionale del termine
polinomio associato a Polynomial. Si puo' omettere il simbolo di
moltiplicazione.

pprint_polynomial(poly([m(-4, 0, []), m(1, 2, [v(1, x), v(1, y)]), m(1, 7, [v(3, s), v(3, t), v(1, y)])])).
-4 + x * y + s^3 * t^3 * y



PREDICATO sum_degrees_variables/2

sum_degrees_variables(VP, TotalDegree)
Il predicato sum_degrees_variables e' vero se TotalDegree e' la somma
di tutti gli esponenti delle VP.

sum_degrees_variables([v(3, s), v(3, t), v(1, x), v(1, y), v(1, y)], TotalDegree).
TotalDegree = 9.


PREDICATO is_monomial/1
is_monomial(Monomio) 
Il predicato is_monomial e' vero se l'oggetto passato e' un monomio.

is_monomial(m(1, 7, [v(3, s), v(3, t), v(1, y)])). 
true.



PREDICATO is_varpower/1

is_varpower(VP)
Il predicato is_varpower e' vero se l'oggetto passato e' un VP.

is_varpower(v(1, x)).
true.


PREDICATO is_polynomial/1

is_polynomial(poly(Monomials))
Il predicato is_polynomial e' vero se l'argomento e' una lista di monomi.

is_polynomial(poly([m(-4, 0, []), m(1, 2, [v(1, x), v(1, y)]), m(1, 7, [v(3, s), v(3, t), v(1, y)])])).
true.



PREDICATO get_power_from_variable/2

get_power_from_variable(VP, Power)
Il predicato get_power_from_variable e' vero se Power e' la potenza
della VP in questione.

get_power_from_variable(v(3, s), X).
X = 3.



PREDICATO get_varsymbol_from_variable/2

get_varsymbol_from_variable(VP, VarSymbol)
Il predicato get_varsymbol_from_variable e' vero se VarSymbol e' il
simbolo di variabile della VP in questione.

get_varsymbol_from_variable(v(3, s), X).
X = s.



PREDICATO get_varsymbols_from_variables/2

get_varsymbols_from_variables(VPS, VS)
Il predicato get_varsymbols_from_variables e' vero quando il secondo
argomento rappresenta la lista dei simboli di variabili presenti nella lista VPS

get_varsymbols_from_variables([v(3, s), v(3, t), v(1, x), v(1, y), v(1, y)], X).
X = [s, t, x, y, y].



PREDICATO get_powers_from_variables/2

get_powers_from_variables(VPS, Power)
Il predicato get_powers_from_variables e' vero quando il secondo
argomento rappresenta la lista delle potenze presenti nella lista VPS.

get_powers_from_variables([v(3, s), v(3, t), v(1, x), v(1, y), v(1, y)], X).
X = [3, 3, 1, 1, 1].



PREDICATO get_coefficient_from_monomial/2

get_coefficient_from_monomial(Monomio, Coefficiente)
Il predicato get_coefficient_from_monomial e' vero quando il secondo
argomento e' il Coefficiente del Monomio passato come primo argomento.

get_coefficient_from_monomial( m(-4, 1, [v(1, x)]), C). 
C = -4. 



PREDICATO get_total_degree_from_monomial/2

get_total_degree_from_monomial(Monomio, TD)
Il predicato get_total_degree_from_monomial e' vero quando il secondo
parametro rappresenta il "total degree" del monomio passato come primo parametro

get_total_degree_from_monomial(m(-4, 1, [v(1, x)]), TD).
TD = 1.



PREDICATO get_variables_from_monomial/2

get_variables_from_monomialget_variables_from_monomial(Monomio, VPs)
Il predicato get_variables_from_monomial e' vero quando il secondo
parametro rappresenta la lista di variabili e potenze che appaiono nel
monomio passato come primo parametro.

get_variables_from_monomial(m(-4, 1, [v(1, x)]), [v(1, x)]).
true.



PREDICATO get_coefficients_from_polynomial/2

get_coefficients_from_polynomial(Poly, Coefficients)
Il predicato get_coefficients_from_polynomial e' vero quando
Coefficients rappresenta la lista dei coefficienti che appaiono nei
monomi che compongono il primo parametro, e' usata all'interno di coefficients.

get_coefficients_from_polynomial(poly([m(1, 2, [v(1, a), v(1, x)]), m(6, 2, [v(1, a), v(1, y)]), m(5, 2, [v(1, b), v(1, x)]), m(3, 2, [v(1, b), v(1, y)])]), X).
X = [1, 6, 5, 3].



PREDICATO get_variables_from_polynomial/2

get_variables_from_polynomial(Poly, Variables)
Il predicato get_variables_from_polynomial e' vero quando Variables
rappresenta la lista ordinata per ordine lessicografico delle
variabili e dei loro gradi presenti in Poly.

get_variables_from_polynomial(poly([m(1, 2, [v(1, a), v(1, x)]), m(6, 2, [v(1, a), v(1, y)]), m(5, 2, [v(1, b), v(1, x)]), m(3, 2, [v(1, b), v(1, y)])]), Variables).
Variables = [v(1, a), v(1, a), v(1, b), v(1, b), v(1, x), v(1, x), v(1, y), v(1, y)].



PREDICATO variables/2

variables(Poly, Variables)
Il predicato variables e' vero quando la lista Variables rappresenta
tutte le variabili presenti nel Poly eliminate le occorrenze.

variables(poly([m(1, 2, [v(1, a), v(1, x)]), m(6, 2, [v(1, a), v(1, y)]), m(5, 2, [v(1, b), v(1, x)]), m(3, 2, [v(1, b), v(1, y)])]), Variables).
Variables = [a, b, x, y].



PREDICATO get_last_mono/2

get_last_mono(Monomi, Max)
Il predicato get_last_mono e' vero quando Max e' l'ultimo monomio
presente nella lista di Monomi passata come primo parametro, usato
nella MaxDegree per estrarre il grado massimo in quanto esso sara'
sicuramente dell'ultimo monomio dato l'ordinamento impostato.

get_last_mono([m(1, 2, [v(1, a), v(1, x)]), m(6, 2, [v(1, a), v(1, y)]), m(5, 2, [v(1, b), v(1, x)]), m(3, 2, [v(1, b), v(1, y)])], Max).
Max = m(3, 2, [v(1, b), v(1, y)]).



PREDICATO reduce_monomial/2

reduce_monomial(Mono, ReducedMono)
Il predicato reduce_monomial e' vero quando ReducedMono rappresenta
il parametro Mono in seguito alla compattazione delle variabili.

reduce_monomial(m(1, 2, [v(1, a), v(1, a)]), X).
X = m(1, 2, [v(2, a)])



PREDICATO sum_similar_monomials_in_poly/2

sum_similar_monomials_in_poly(Poly1, Poly2)
Il predicato sum_similar_monomials_in_poly e' vero quando Poly2
rappresenta il Poly1 con tutti i monomi simili sommati.

sum_similar_monomials_in_poly(poly([m(1, 2, [v(1, a), v(1, x)]), m(6, 2, [v(1, a), v(1, x)]), m(5, 2, [v(1, b), v(1, x)]), m(3, 2, [v(1, b), v(1, x)])]), X).
X = poly([m(7, 2, [v(1, a), v(1, x)]), m(8, 2, [v(1, b), v(1, x)])]).



PREDICATO as_monomial/2

as_monomial(Expression, Monomial)
Il predicato as_monomial e' vero quando Monomial e' la
rappresentazione standard del primo predicato ordinato e compattato.

as_monomial(x*x*x^5*y*z^9*e, X).
X = m(1, 18, [v(1, e), v(7, x), v(1, y), v(9, z)]).



PREDICATO as_monomial_unordered/2

as_monomial_unordered(Expression, Mono)
Il predicato as_monomial_unordered e' vero quando Mono e' la
rappresentazione standard di Expression la quale rappresenta la
versione tradizionale di un monomio.

as_monomial_unordered(x*x*x^5*y*z^9*e, X).
X = m(1, 18, [v(1, e), v(9, z), v(1, y), v(5, x), v(1, x), v(1, x)]).



PREDICATO compare_variables/3

compare_variables(< o >, VPS1, VPS2)
Il predicato compare_variables e' vero quando, in base al predicato >
o <, VPS1 risultera' essere maggiore( o minore) rispetto a VPS2.
Usato, insieme a compare_monomials, per effettuare l'ordinamento
all'interno del polinomio

compare_variables(>,  v(9, z),  v(3, z)).
true.
compare_variables(<,  v(9, z),  v(3, z)).
false.



PREDICATO compare_monomials/3

compare_monomials(< o >, Mono1, Mono2)
Il predicato compare_monomials e' vero quando, in base al predicato >
o <, Mono1 risultera' essere maggiore( o minore) rispetto a Mono2.
Usato per effettuare l'ordinamento all'interno del polinomio.

compare_monomials(<, m(7, 3, [v(2, a), v(1, x)]), m(7, 2, [v(1, a), v(1, x)])).
false. 
compare_monomials(>, m(7, 3, [v(2, a), v(1, x)]), m(7, 2, [v(1, a), v(1, x)])).
true.



PREDICATO sort_monomials_in_polynomial/2

sort_monomials_in_polynomial(Poly1, Poly2)
Il predicato sort_monomials_in_polynomial e' vero quando Poly2
rappresenta Poly1 in seguito all'ordinamento lessicografico e' in base al grado

sort_monomials_in_polynomial(poly([m(7, 2, [v(1, a), v(1, x)]), m(8, 1, [v(1, b)]),m(7, 5, [v(3, a), v(2, x)])]), X).
X = poly([m(8, 1, [v(1, b)]), m(7, 2, [v(1, a), v(1, x)]), m(7, 5, [v(3, a), v(2, x)])]).



PREDICATO as_polynomial/2

as_polynomial(Expression, Polynomial)
Il predicato as_polynomial e' vero quando Polynomial rappresenta la
rappresentazione standard del primo parametro ordinata e con la
eliminazione dei monomi con il  coefficiente a 0.

as_polynomial(4+5*x-7*x^2*y^3, X).
X = poly([m(4, 0, []), m(5, 1, [v(1, x)]), m(-7, 5, [v(2, x), v(3, y)])]).



PREDICATO as_polynomialCall/2

as_polynomialCall(Expression, Poly)
Il predicato as_polynomialCall e' vero quando Poly rappresenta la
rappresentazione standard del primo parametro, usato in as_polynomial

as_polynomialCall(0*x*y*k+6*r^2-42+7*p, X).
X = poly([m(-42, 0, []), m(7, 1, [v(1, p)]), m(6, 2, [v(2, r)])]).



PREDICATO to_polynomial/2

to_polynomial(Poly, ParsedPoly)
Il predicato to_polynomial e' vero quando ParsedPoly rappresenta il
primo parametro in seguito all'ordinamento.

to_polynomial( poly([m(4, 0, []), m(5, 4, [v(4, x)]), m(-7, 2, [v(1, x), v(1, y)]), m(3, 0, [])]), X).
X = poly([m(7, 0, []), m(-7, 2, [v(1, x), v(1, y)]), m(5, 4, [v(4, x)])]).



PREDICATO evaluate_poly/3

evaluate_poly(Poly, Alternated, Value)
Il predicato evaluate_poly e' vero quando Value rappresenta il valore
del Poly in seguito alla sostituzione dei valori, contenuti in
Alternated, alle variabili.

evaluate_poly( poly([m(7, 0, []), m(-7, 2, [v(1, x), v(1, y)])]), [x,2,y,1], X).
X = -7.



PREDICATO substitute_vars/3

substitute_vars(OLDVPS, VALUE, NEWVPS)
Il predicato substitute_vars e' vero quando NEWVPS rappresenta la
lista delle variabili sostituite con i valori di VALUE corrispondenti.

substitute_vars([v(1, x), v(1, y)], [x,2,y,1], X).
X = [v(1, 2), v(1, 1)].



PREDICATO substitute_mono/3

substitute_mono(Mono1, Alternated, Mono2)
Il predicato substitute_mono e' vero se Mono2 rappresenta Mono1 con al
posto delle variabili i valori contenuti in alternated.

substitute_mono(m(-7, 2, [v(1, x), v(1, y)]), [x,2,y,1], X). 
X = m(-7, 2, [v(1, 2), v(1, 1)]).



PREDICATO evaluate_vars/2

evaluate_mono(Mono, Alternated, Value)
Il predicato evaluate_mono e' vero se Value rappresenta il valore di
Mono in seguito alla sostituzione delle variabili, con i valori
contenuti in Alternated, e alle varie operazioni matematiche.

evaluate_mono(m(-7, 2, [v(1, x), v(1, y)]),  [x,2,y,1], Value).
Value = -14.



PREDICATO opposite_polynomial/2

opposite_polynomial(Poly1, Poly2)
Il predicato opposite_polynomial e' vero quando Poly2 rappresenta
Poly1 con tutti i coefficienti dei vari monomi cambiati di segno.
Usato per implementare polyminus.

opposite_polynomial(poly([m(7, 0, []), m(-7, 2, [v(1, x), v(1, y)]), m(5, 4, [v(4, x)])]), X).
X = poly([m(-7, 0, []), m(7, 2, [v(1, x), v(1, y)]), m(-5, 4, [v(4, x)])]).



PREDICATO reduce_all_monos/2

reduce_all_monos(Poly1, Poly2)
Il predciato reduce_all_monos e' vero quando Poly2 rappresenta Poly1
in seguito alla compatazione delle variabili.

reduce_all_monos(poly([m(-7, 0, []), m(7, 2, [v(1, x), v(1, x)]), m(-5, 4, [v(4, x)])]), X).
X = poly([m(-7, 0, []), m(7, 2, [v(2, x)]), m(-5, 4, [v(4, x)])]).



PREDICATO remove_coeff_zero/2

remove_coeff_zero(Poly1, Poly2)
Il predicato remove_coeff_zero e' vero quando Poly2 rappresenta Poly1
privato di tutti i monomi con coeff pari a 0

remove_coeff_zero(poly([m(-7, 0, []), m(7, 2, [v(2, x)]), m(0, 4, [v(4, x)])]), X).
X = poly([m(-7, 0, []), m(7, 2, [v(2, x)])]).



PREDICATO multiply_variables/3

multiply_variables(VPS1, VPS2, VPSRIS)
Il predicato multiply_variables e' vero quando VPSRIS rappresenta il
risultato del prodotto tra VPS1 e VPS2.

multiply_variables([v(2, x)],[v(4, x)], X).
X = [v(6, x)].



PREDICATO mono_times/3

mono_times(Mono1, Mono2, MonoRis)
Il predicato mono_times e' vero quando MonoRis e' uguale al prodotto
tra Mono1 e Mono2.

mono_times(m(7, 2, [v(2, x)]), m(-5, 4, [v(4, x)]), X).
X = m(-35, 6, [v(6, x)]).



PREDICATO print_vps/1

print_vps(VPS)
Il predicato stampa la VPS nella forma tradizionale.

print_vps( [v(2, x)]).
x^2.






 



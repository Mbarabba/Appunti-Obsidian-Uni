LP_E1P_JSON_2017: A JSON Parser

Group components:
816042 Porto Francesco
817315 Pelliccioli Simone
820934 Valli Mattia

Main features:
-Directly parses a given JSONString into a Prolog-friendly form
-Retrieves a certain value from a JSON given a list of parameters
-Writes/Reads a JSON from/to a file

How to use this program (with a file):
1) Call json_load(Filename, X), X will be your json in prolog-form.
2) Call json_get(X, Fields, Y), in order to retrieve a certain element from your json in Y.
3) Call json_write(X, Filename), your json will be written to a file with name Filename.

Of course you can also use this program with a given String (insted of a file) by calling 
json_parse(JSONString, X)!

Can also be found on Github:
https://github.com/HopedWall/JSONinProlog-Lisp

Thanks for reading!
Componenti del gruppo:

% Leonetti Alessandro 746215
% Cassataro Riccardo 736424

Commenti e descrizioni del programma svolto:

1) is_regexp(RE):

	considera il caso base in cui l'espressione regolare � un atomo,
	considera il caso base in cui l'espressione regolare � epsilon,
	considera i casi ricorsivi: 
	sequenza,
	unione,
	chiusura di kleene,
	negazione,
	oneof,
	plus

 I predicati seq e oneof sono stati gestiti grazie all'utilizzo dell'univ che decompone un termine in una lista.

2) nfa_compile_regexp(FA_Id, RE):

	viene definito un predicato base di ariet� 2 che grazie all'utilizzo del gensym crea
	gli stati Iniziale e Finale di tutti gli automi.
	A questo predicato si collegano poi ricorsivamente tutti gli altri predicati con ariet� 4
	che gestiscono la costruzione degli automi per ogni specifica operazione:
            
	- lettura di una stringa di un solo carattere
	- Or tra due espressioni regolari
	- Star
	- plus
	- concatenazione
	- oneof


3) nfa_recognize(FA_Id, Input):


	� stato gestito il caso base in cui vi � in ingresso una lista vuota,
	poi � stato considerato il caso delle epsilon mosse che si possono
	presentare tra i vari stati dell'automa, infine viene gestito il caso in cui vi sia
	in input una lista di caratteri. E' stato creato un nfa_recognize di ariet� 3 
	che tiene conto dello stato in cui si trova l'automa dopo aver letto un certo valore,
	viene valutato anche in questo metodo il caso in cui si presenta l'espilon mossa.

	
Inoltre sono stati gestiti i metodi nfa_list ed nfa_clear che puliscono e listano l'automa.






% Leonetti_Alessandro_746215
% Cassataro_Riccardo_736424


% 1. is_regexp

% Caso Base: Atomic

	 is_regexp(RE) :- atomic(RE).

% Caso Base:epsilon e insieme vuoto

	is_regexp(epsilon).


% Caso Ricorsivo: Sequenza

	is_regexp(RE) :- RE=..[seq|R1], regular_exp(R1).
	regular_exp(R1) :- is_regexp(R1).
	regular_exp([R1|R2]) :- is_regexp(R1), regular_exp(R2).


% Caso Ricorsivo: Unione - Or

	is_regexp(or(RE1, RE2)) :-
	is_regexp(RE1), is_regexp(RE2).

% Caso Ricorsivo: chiusura di Kleene

	is_regexp(star(RE)) :- is_regexp(RE).

% Caso Ricorsivo: Negazione

	is_regexp(bar(RE)) :- is_regexp(RE).

% Caso Ricorsivo: oneof

	is_regexp(RE) :- RE=..[oneof|R1], regular_exp(R1).

%Caso Ricorsivo: Plus

	is_regexp(plus(RE)) :- is_regexp(RE).

% 2) nfa_compile_regexp


	% arit� 2

		nfa_compile_regexp(FA_Id, RE) :-
			gensym(q, Iniziale),
			assert(nfa_initial(FA_Id, Iniziale)),
			gensym(p, Finale),
			assert(nfa_final(FA_Id, Finale)),
			nfa_compile_regexp(FA_Id, RE, Iniziale, Finale).

	% Lettura di una stringa di un solo carattere

		nfa_compile_regexp(FA_Id, RE, Iniziale, Finale) :-
			atomic(RE),
			assert(nfa_delta(FA_Id, Iniziale, RE, Finale)).

	% OR(RE1,RE2)

		nfa_compile_regexp(FA_Id, or(RE1,RE2), Iniziale, Finale) :-
			gensym(q, Ini1),
			gensym(q, Ini2),
			assert(nfa_delta(FA_Id, Iniziale, epsilon, Ini1)),
			assert(nfa_delta(FA_Id, Iniziale, epsilon, Ini2)),
			gensym(q, Fin1),
			gensym(q, Fin2),
			assert(nfa_delta(FA_Id, Fin1, epsilon, Finale)),
			assert(nfa_delta(FA_Id, Fin2, epsilon, Finale)),
			nfa_compile_regexp(FA_Id, RE1, Ini1, Fin1),
			nfa_compile_regexp(FA_Id, RE2, Ini2, Fin2).


	% STAR

	nfa_compile_regexp(FA_Id, star(RE), Iniziale, Finale) :-
		assert(nfa_delta(FA_Id, Iniziale, epsilon, Finale)),
		gensym(q, Inre),
		assert(nfa_delta(FA_Id, Iniziale, epsilon, Inre)),
		gensym(q, Finre),
		assert(nfa_delta(FA_Id, Finre, epsilon, Inre)),
		assert(nfa_delta(FA_Id, Finre, epsilon, Finale)),
		nfa_compile_regexp(FA_Id ,RE, Inre, Finre).

	%PLUS

	nfa_compile_regexp(FA_Id, plus(RE), Iniziale, Finale) :-
			nfa_compile_regexp(FA_Id, seq(RE, RE, star(RE)), Iniziale, Finale).


	%CONCATENAZIONE

	nfa_compile_regexp(FA_Id, RE, Iniziale, Finale) :-
		RE =..[seq, R1],
		nfa_compile_regexp(FA_Id, R1, Iniziale, Finale).
	nfa_compile_regexp(FA_Id, RE, Iniziale, Finale) :-
		RE =..[seq, R1, R2],
		gensym(q, Fin1),
		nfa_compile_regexp(FA_Id, R1, Iniziale, Fin1),
		gensym(q, In1),
		assert(nfa_delta(FA_Id, Fin1, epsilon, In1)),
		nfa_compile_regexp(FA_Id, R2, In1, Finale), !.
	nfa_compile_regexp(FA_Id, RE, Iniziale, Finale) :-
		RE =..[seq, R1, R2|R3],
		gensym(q, Fin1),
		nfa_compile_regexp(FA_Id, R1, Iniziale, Fin1),
		gensym(q, In1), gensym(q, Fin2),
		assert(nfa_delta(FA_Id, Fin1, epsilon, In1)),
		nfa_compile_regexp(FA_Id, R2, In1, Fin2),
		gensym(q, In2),
		assert(nfa_delta(FA_Id, Fin2, epsilon, In2)),
		nfa_compile_regexp(FA_Id, R3, In2, Finale), !.
	nfa_compile_regexp(FA_Id, [RE], Iniziale, Finale) :-
		nfa_compile_regexp(FA_Id, RE, Iniziale, Finale).
	nfa_compile_regexp(FA_Id, [R1|R2], Iniziale, Finale) :-
		gensym(q, Fin1),
		nfa_compile_regexp(FA_Id, R1, Iniziale, Fin1),
		gensym(q, In1),
		assert(nfa_delta(FA_Id, Fin1, epsilon, In1)),
		nfa_compile_regexp(FA_Id, R2, In1, Finale).



	%ONEOF

	nfa_compile_regexp(FA_Id, RE, Iniziale, Finale) :-
		RE =..[oneof, R1],
		nfa_compile_regexp(FA_Id, R1, Iniziale, Finale).
	nfa_compile_regexp(FA_Id, RE, Iniziale, Finale) :-
		RE =..[oneof, R1, R2],
		nfa_compile_regexp(FA_Id, or(R1,R2), Iniziale, Finale), !.
	nfa_compile_regexp(FA_Id, RE, Iniziale, Finale) :-
		RE =..[oneof, R1, R2|R3],
		gensym(q, In1), gensym(q, Fin1),
		assert(nfa_delta(FA_Id, Iniziale, epsilon, In1)),
		assert(nfa_delta(FA_Id, Fin1, epsilon, Finale)),
		nfa_compile_regexp(FA_Id, R1, In1, Fin1),
		gensym(q, In2), gensym(q, Fin2),
		assert(nfa_delta(FA_Id, Iniziale, epsilon, In2)),
		assert(nfa_delta(FA_Id, Fin2, epsilon, Finale)),
		nfa_compile_regexp(FA_Id, R2, In2, Fin2),
		gensym(q, In3), gensym(q, Fin3),
		assert(nfa_delta(FA_Id, Iniziale, epsilon, In3)),
		assert(nfa_delta(FA_Id, Fin3, epsilon, Finale)),
		nfa_compile_regexp1(FA_Id, R3, In3, Fin3, Iniziale, Finale), !.
	nfa_compile_regexp1(FA_Id, [RE], Iniziale, Finale, _, _) :-
		nfa_compile_regexp(FA_Id, RE, Iniziale, Finale).
	nfa_compile_regexp1(FA_Id, [R1|R2], In, Fin, Iniziale, Finale) :-
		assert(nfa_delta(FA_Id, In, R1, Fin)),
		gensym(q, In1), gensym(q, Fin1),
		assert(nfa_delta(FA_Id, Iniziale, epsilon, In1)),
		assert(nfa_delta(FA_Id, Fin1, epsilon, Finale)),
		nfa_compile_regexp1(FA_Id, R2, In1, Fin1, Iniziale, Finale).

%3) NFA_RECOGNIZE

	nfa_recognize(FA_Id, []) :-
		nfa_initial(FA_Id, Q),
		nfa_recognize(FA_Id, [], Q).
	nfa_recognize(FA_Id, []) :-
		nfa_initial(FA_Id, Q),
		nfa_delta(FA_Id, Q, X, NewQ),
		X=epsilon, nfa_recognize(FA_Id, [], NewQ).
	nfa_recognize(FA_Id, []) :-
		nfa_initial(FA_Id, Q),
		nfa_delta(FA_Id, Q, X, NewQ),
		X=[], nfa_recognize(FA_Id, [], NewQ).
	nfa_recognize(FA_Id, [X|Xs]) :-
		nfa_initial(FA_Id, Q),
		nfa_delta(FA_Id, Q, X, NewQ),
		nfa_recognize(FA_Id, Xs, NewQ).
	nfa_recognize(FA_Id, [X|Xs]) :-
		nfa_initial(FA_Id, Q), T=[],
		nfa_delta(FA_Id, Q, T, NewQ),
		nfa_recognize(FA_Id, [X|Xs], NewQ).
	nfa_recognize(FA_Id, [X|Xs]) :-
		nfa_initial(FA_Id, Q), T=epsilon,
		nfa_delta(FA_Id, Q, T, NewQ),
		nfa_recognize(FA_Id, [X|Xs], NewQ).
	nfa_recognize(FA_Id, [], Stato) :-
		nfa_final(FA_Id, Stato).
	nfa_recognize(FA_Id, [], Stato) :-
		nfa_delta(FA_Id, Stato, X, NewQ),
		X=epsilon,nfa_recognize(FA_Id, [], NewQ).
	nfa_recognize(FA_Id, [Simbolo|Input], Stato) :-
		nfa_delta(FA_Id, Stato, X, NewQ),
		X=epsilon,
		nfa_recognize(FA_Id, [Simbolo|Input], NewQ).
	nfa_recognize(FA_Id, [Simbolo|Input], Stato) :-
		nfa_delta(FA_Id, Stato, Simbolo, NuovoStato),
		nfa_recognize(FA_Id, Input, NuovoStato).


	%CLEAR

	nfa_clear(FA_Id) :-
		retract(nfa_delta(FA_Id, _, _, _)),
		nfa_clear(FA_Id).
	nfa_clear(FA_Id) :-
		retract(nfa_initial(FA_Id, _)),
		retract(nfa_final(FA_Id, _)).



	nfa_clear :-
		retractall(nfa_initial(_, _)),
		retractall(nfa_final(_, _)),
		retractall(nfa_delta(_, _, _, _)).

	%LIST

	nfa_list(FA_Id) :-
		listing(nfa_delta(FA_Id, _, _, _)),
		listing(nfa_final(FA_Id, _)),
		listing(nfa_initial(FA_Id, _)).



	nfa_list :-
		listing(nfa_delta(_, _, _, _)),
		listing(nfa_initial(_, _)),
		listing(nfa_final(_, _)).
